<?php
// ************************************
// This file is part of a package from:
// www.freecontactform.com

// Free Version
// 15 September 2020

// You are free to use an edit for 
// your own use. But cannot resell
// or repackage in any way.
// ************************************

require dirname(__FILE__).'/'.'fcf.config.php';
require dirname(__FILE__).'/'.'process.php';